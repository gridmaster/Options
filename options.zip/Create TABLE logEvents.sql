USE [MarketProphet]
GO

/****** Object:  Table [dbo].[LogEvents]    Script Date: 04/15/2016 14:07:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LogEvents](
	[LogEventId] [int] IDENTITY(1,1) NOT NULL,
	[Location] [nvarchar](256) NULL,
	[Description] [nvarchar](max) NULL,
	[Timestamp] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[LogEventId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


