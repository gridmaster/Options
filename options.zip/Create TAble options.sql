USE [MarketProphet]
GO

/****** Object:  Table [dbo].[Options]    Script Date: 04/15/2016 14:07:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Options](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Symbol] [varchar](20) NOT NULL,
	[ExperationDate] [nvarchar](30) NOT NULL,
	[CallPut] [varchar](4) NOT NULL,
	[Strike] [decimal](18, 2) NOT NULL,
	[ContractName] [nvarchar](30) NOT NULL,
	[Last] [decimal](18, 2) NOT NULL,
	[Bid] [decimal](18, 2) NOT NULL,
	[Ask] [decimal](18, 2) NOT NULL,
	[Change] [decimal](18, 2) NOT NULL,
	[InTheMoney] [bit] NOT NULL,
	[PercentChange] [varchar](20) NOT NULL,
	[Volume] [decimal](18, 0) NULL,
	[OpenInterest] [decimal](18, 2) NULL,
	[ImpliedVolatility] [varchar](20) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[Timestamp] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[DateCreated] ASC,
	[Symbol] ASC,
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


